package marsrover;

public class MaxArea {

    private int maxXPosition;
    private int maxYPosition;

    public int getMaxXPosition() {
        return maxXPosition;
    }

    public void setMaxXPosition(int maxXPosition) {
        this.maxXPosition = maxXPosition;
    }

    public int getMaxYPosition() {
        return maxYPosition;
    }

    public void setMaxYPosition(int maxYPosition) {
        this.maxYPosition = maxYPosition;
    }
}
